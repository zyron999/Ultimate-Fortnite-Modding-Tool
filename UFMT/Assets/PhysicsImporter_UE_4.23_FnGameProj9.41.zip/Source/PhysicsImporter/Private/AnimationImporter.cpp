#include "AnimationImporter.h"

#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Animation/AnimCurveTypes.h"
#include "Curves/RichCurve.h"
#include "UObject/Package.h"
#include "ScopedTransaction.h"

DEFINE_LOG_CATEGORY_STATIC(LogAnimationImporter, Log, All);

namespace
{
    FRichCurveKey ObjectToRichCurveKey(const TSharedPtr<FJsonObject>& Object)
    {
        const FString InterpMode = Object->GetStringField(TEXT("InterpMode"));

        return FRichCurveKey(
            Object->GetNumberField(TEXT("Time")),
            Object->GetNumberField(TEXT("Value")),
            Object->GetNumberField(TEXT("ArriveTangent")),
            Object->GetNumberField(TEXT("LeaveTangent")),
            static_cast<ERichCurveInterpMode>(StaticEnum<ERichCurveInterpMode>()->GetValueByNameString(InterpMode)));
    }

    bool IsProperExportData(const TSharedPtr<FJsonObject>& JsonObject)
    {
        return JsonObject.IsValid()
            && JsonObject->HasField(TEXT("Type"))
            && JsonObject->HasField(TEXT("Name"))
            && JsonObject->HasField(TEXT("Properties"));
    }
}

void UAnimationImporter::SetAnimSequenceLength(UAnimSequence* AnimSequence, float NewLength)
{
    if (!AnimSequence || NewLength <= 0.f)
    {
        return;
    }

    const float OldLength = AnimSequence->SequenceLength;
    if (FMath::IsNearlyEqual(OldLength, NewLength))
    {
        return;
    }

    const FScopedTransaction Transaction(FText::FromString(
        FString::Printf(TEXT("Change Sequence Length %.3f to %.3f"), OldLength, NewLength)));

    AnimSequence->Modify();
    AnimSequence->SequenceLength = NewLength;

}

void UAnimationImporter::ImportFloatCurves(const TSharedPtr<FJsonObject>& Properties, const TSharedPtr<FJsonObject>& AssetExport, UAnimSequence* AnimSequence)
{
    if (!AssetExport.IsValid() || !AnimSequence)
    {
        return;
    }

    USkeleton* Skeleton = AnimSequence->GetSkeleton();
    if (!Skeleton)
    {
        UE_LOG(LogAnimationImporter, Error, TEXT("ImportFloatCurves: AnimSequence '%s' has no valid Skeleton."), *AnimSequence->GetName());
        return;
    }

    TArray<TSharedPtr<FJsonValue>> FloatCurves;

    const TSharedPtr<FJsonObject>* RawCurveDataObject = nullptr;
    if (Properties.IsValid() && Properties->TryGetObjectField(TEXT("RawCurveData"), RawCurveDataObject) && RawCurveDataObject->IsValid())
    {
        const TArray<TSharedPtr<FJsonValue>>* RawFloatCurves = nullptr;
        if ((*RawCurveDataObject)->TryGetArrayField(TEXT("FloatCurves"), RawFloatCurves))
        {
            FloatCurves = *RawFloatCurves;
        }
    }

    if (FloatCurves.Num() == 0)
    {
        const TSharedPtr<FJsonObject>* CompressedCurveDataObject = nullptr;
        if (AssetExport->TryGetObjectField(TEXT("CompressedCurveData"), CompressedCurveDataObject) && CompressedCurveDataObject->IsValid())
        {
            const TArray<TSharedPtr<FJsonValue>>* CompressedFloatCurves = nullptr;
            if ((*CompressedCurveDataObject)->TryGetArrayField(TEXT("FloatCurves"), CompressedFloatCurves))
            {
                FloatCurves = *CompressedFloatCurves;
            }
        }
    }

    if (FloatCurves.Num() == 0)
    {
        UE_LOG(LogAnimationImporter, Warning, TEXT("ImportFloatCurves: No FloatCurves found in JSON for '%s'."), *AnimSequence->GetName());
        return;
    }

    AnimSequence->Modify();

    AnimSequence->RawCurveData.FloatCurves.Empty();

    for (const TSharedPtr<FJsonValue>& FloatCurveValue : FloatCurves)
    {
        const TSharedPtr<FJsonObject> FloatCurveObject = FloatCurveValue->AsObject();
        if (!FloatCurveObject.IsValid())
        {
            continue;
        }

        FString DisplayName;
        if (FloatCurveObject->HasField(TEXT("Name")))
        {
            DisplayName = FloatCurveObject->GetObjectField(TEXT("Name"))->GetStringField(TEXT("DisplayName"));
        }
        else
        {
            DisplayName = FloatCurveObject->GetStringField(TEXT("CurveName"));
        }

        if (DisplayName.IsEmpty())
        {
            continue;
        }

        const int32 CurveTypeFlags = FloatCurveObject->GetIntegerField(TEXT("CurveTypeFlags"));

        FSmartName NewTrackName;
        Skeleton->AddSmartNameAndModify(USkeleton::AnimCurveMappingName, FName(*DisplayName), NewTrackName);
        ensureAlways(Skeleton->GetSmartNameByUID(USkeleton::AnimCurveMappingName, NewTrackName.UID, NewTrackName));

        if (!FloatCurveObject->HasField(TEXT("FloatCurve")))
        {
            continue;
        }

        const TSharedPtr<FJsonObject> FloatCurveDataObject = FloatCurveObject->GetObjectField(TEXT("FloatCurve"));
        const TArray<TSharedPtr<FJsonValue>> Keys = FloatCurveDataObject->GetArrayField(TEXT("Keys"));

        FRawCurveTracks& Tracks = AnimSequence->RawCurveData;

        for (const TSharedPtr<FJsonValue>& JsonKeyValue : Keys)
        {
            const TSharedPtr<FJsonObject> KeyObject = JsonKeyValue->AsObject();
            if (!KeyObject.IsValid())
            {
                continue;
            }

            const FRichCurveKey RichKey = ObjectToRichCurveKey(KeyObject);

            Tracks.AddFloatCurveKey(NewTrackName, CurveTypeFlags, RichKey.Time, RichKey.Value);

            for (FFloatCurve& Track : Tracks.FloatCurves)
            {
                if (Track.Name == NewTrackName)
                {
                    const int32 LastIndex = Track.FloatCurve.Keys.Num() - 1;
                    Track.FloatCurve.Keys[LastIndex].ArriveTangent = RichKey.ArriveTangent;
                    Track.FloatCurve.Keys[LastIndex].LeaveTangent = RichKey.LeaveTangent;
                    Track.FloatCurve.Keys[LastIndex].InterpMode = RichKey.InterpMode;
                }
            }
        }
    }

    AnimSequence->MarkRawDataAsModified();
}

bool UAnimationImporter::ImportAnimationSequence(const FString& JsonString, const FString& AnimSequencePath)
{
    TArray<TSharedPtr<FJsonValue>> ExportsArray;

    TSharedPtr<FJsonObject> RootObject;
    const TSharedRef<TJsonReader<>> ObjectReader = TJsonReaderFactory<>::Create(JsonString);
    if (FJsonSerializer::Deserialize(ObjectReader, RootObject) && RootObject.IsValid())
    {
        if (RootObject->HasField(TEXT("Exports")))
        {
            ExportsArray = RootObject->GetArrayField(TEXT("Exports"));
        }
        else if (RootObject->HasField(TEXT("Type")))
        {
            ExportsArray.Add(MakeShareable(new FJsonValueObject(RootObject)));
        }
    }
    else
    {
        const TSharedRef<TJsonReader<>> ArrayReader = TJsonReaderFactory<>::Create(JsonString);
        FJsonSerializer::Deserialize(ArrayReader, ExportsArray);
    }

    if (ExportsArray.Num() == 0)
    {
        UE_LOG(LogAnimationImporter, Error, TEXT("No exports found in animation JSON."));
        return false;
    }

    TSharedPtr<FJsonObject> AssetExport;
    for (const TSharedPtr<FJsonValue>& ExportValue : ExportsArray)
    {
        const TSharedPtr<FJsonObject> ExportObject = ExportValue->AsObject();
        if (ExportObject.IsValid() && IsProperExportData(ExportObject) && ExportObject->GetStringField(TEXT("Type")) == TEXT("AnimSequence"))
        {
            AssetExport = ExportObject;
            break;
        }
    }

    if (!AssetExport.IsValid())
    {
        UE_LOG(LogAnimationImporter, Error, TEXT("AnimSequence export not found in JSON."));
        return false;
    }

    const TSharedPtr<FJsonObject> Properties = AssetExport->GetObjectField(TEXT("Properties"));

    FString ObjectPath = AnimSequencePath;
    if (!ObjectPath.Contains(TEXT(".")))
    {
        const FString ObjectName = FPackageName::GetLongPackageAssetName(ObjectPath);
        ObjectPath = FString::Printf(TEXT("%s.%s"), *ObjectPath, *ObjectName);
    }

    UAnimSequence* AnimSequence = Cast<UAnimSequence>(StaticLoadObject(UAnimSequence::StaticClass(), nullptr, *ObjectPath));
    if (!AnimSequence)
    {
        UE_LOG(LogAnimationImporter, Error, TEXT("ImportAnimationSequence: Could not load existing AnimSequence at '%s'."), *ObjectPath);
        return false;
    }

    AnimSequence->AuthoredSyncMarkers.Empty();
    AnimSequence->Notifies.Empty();

    if (Properties.IsValid() && Properties->HasField(TEXT("SequenceLength")))
    {
        const float SequenceLength = Properties->GetNumberField(TEXT("SequenceLength"));
        SetAnimSequenceLength(AnimSequence, SequenceLength);
    }

    ImportFloatCurves(Properties, AssetExport, AnimSequence);

    AnimSequence->RequestSyncAnimRecompression();
    AnimSequence->PostProcessSequence();
    AnimSequence->PostEditChange();
    AnimSequence->MarkPackageDirty();

    UE_LOG(LogAnimationImporter, Log, TEXT("Imported animation data onto '%s'."), *AnimSequence->GetName());

    return true;
}