using UnrealBuildTool;

public class PhysicsImporter : ModuleRules
{
    public PhysicsImporter(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[] {
            "Core",
            "CoreUObject",
            "Engine",
            "Json",
            "JsonUtilities",
            "AssetRegistry",
            "UnrealEd",
            "Kismet",
            "BlueprintGraph",
            "AnimGraph",
            "AnimGraphRuntime",
	    "EditorScriptingUtilities"
        });
    }
}